package microservice.example.trampoline.Entities;

import jdk.jfr.EventType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionEvent extends AccountEvent {

    private String transactionid;
    private microservice.example.trampoline.Entities.EventType eventType;




}
