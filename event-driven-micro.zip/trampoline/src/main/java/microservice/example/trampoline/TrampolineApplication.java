package microservice.example.trampoline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrampolineApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrampolineApplication.class, args);
	}

}
