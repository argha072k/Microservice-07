package microservice.example.trampoline.Entities;

import jdk.jfr.EventType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountEvent {

    private String accountid;
    private microservice.example.trampoline.Entities.EventType eventType;



}
