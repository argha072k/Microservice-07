package microservice.example.trampoline.Topics;


import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class TopicConfig {

    public NewTopic topic1(){
        return TopicBuilder
                .name("account-details")
                .build();
    }

    public NewTopic topic2(){
        return TopicBuilder
                .name("transaction-details")
                .build();
    }
}
