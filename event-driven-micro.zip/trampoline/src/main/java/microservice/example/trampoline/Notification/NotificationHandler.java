package microservice.example.trampoline.Notification;

public class NotificationHandler {
}
