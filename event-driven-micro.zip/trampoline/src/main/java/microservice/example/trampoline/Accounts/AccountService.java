package microservice.example.trampoline.Accounts;


import microservice.example.trampoline.Entities.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    private final KafkaTemplate<String, AccountEvent>kafkaTemplate;

    public AccountService(KafkaTemplate<String, AccountEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }


    public void createAccount(UserAccount account){
        AccountEvent accountEvent=new AccountEvent(account.getId(), EventType.ACCOUNT_CREATED);
        kafkaTemplate.send("account-details",accountEvent);
    }

    public void initiateTransaction(Transaction transaction){
        TransactionEvent transactionEvent=new TransactionEvent(transaction.getId(), EventType.TRANSACTION_INITIATED);
        kafkaTemplate.send("transaction-details",transactionEvent);
    }
}
