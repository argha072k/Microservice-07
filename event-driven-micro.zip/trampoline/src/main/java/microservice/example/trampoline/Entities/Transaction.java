package microservice.example.trampoline.Entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Transaction {

    private String id;
    private String accountNo;
    private BigDecimal amount;
}
