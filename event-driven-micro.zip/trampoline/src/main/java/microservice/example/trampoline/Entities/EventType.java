package microservice.example.trampoline.Entities;

public enum EventType {


        ACCOUNT_CREATED,
        TRANSACTION_INITIATED,

        TRANSACTION_COMPLETED,



}
