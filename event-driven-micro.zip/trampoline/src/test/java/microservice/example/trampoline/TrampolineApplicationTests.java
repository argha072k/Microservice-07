package microservice.example.trampoline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrampolineApplicationTests {

	@Test
	void contextLoads() {
	}

}
