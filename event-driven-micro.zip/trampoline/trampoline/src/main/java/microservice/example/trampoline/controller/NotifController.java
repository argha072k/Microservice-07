package microservice.example.trampoline.controller;
import microservice.example.trampoline.models.Transaction;
import microservice.example.trampoline.models.UserAccount;
import microservice.example.trampoline.service.AccountService;
import microservice.example.trampoline.service.FraudDetectionService;
import microservice.example.trampoline.service.TransactionService;
import org.h2.engine.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/handle")
public class NotifController {

    private AccountService accountService;

    private TransactionService transactionService;

    private FraudDetectionService fraudDetectionService;

    public NotifController(AccountService accountService, TransactionService transactionService, FraudDetectionService fraudDetectionService) {
        this.accountService = accountService;
        this.transactionService = transactionService;
        this.fraudDetectionService = fraudDetectionService;
    }

    // to create a new account
    @PostMapping("/account")
    public ResponseEntity<?> createaccount(@RequestBody UserAccount account){
        if(fraudDetectionService.FraudAccount(account)){
            return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body("fraud account detected...account blocked");

        }

        ResponseEntity<?>response=accountService.createaccount(account);
        return response;

    }

    //to fetch an account with account number
    @GetMapping("/getaccount/{accountNo}")
    public ResponseEntity<UserAccount>getbyaccountNo(@PathVariable String accountNo){
        UserAccount account=accountService.getbyAccountNo(accountNo);
        return ResponseEntity.ok(account);
    }

    // to unblock an account
    @PostMapping("/unblock/{accountNo}")
    public ResponseEntity<?>unblockaccount(@PathVariable String accountNo){
        ResponseEntity<?>response=accountService.unblockaccount(accountNo);
        return response;
    }


    // to credit user account with an amount
    @PostMapping("/add")
    public ResponseEntity<?> performtransaction1(@RequestBody Transaction transaction)
    {
        if(fraudDetectionService.FraudThresholdTransaction(transaction) || fraudDetectionService.FraudcountTransaction(transaction.getAccountNo())){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("fraud transaction detected...account blocked");
        }
        ResponseEntity<?>response=transactionService.addTransaction(transaction.getAccountNo(), transaction.getAmount());
        return response;
    }

    // to debit user account with an amount
    @PostMapping("/sub")
    public ResponseEntity<?> performtransaction2(@RequestBody Transaction transaction)
    {
        if(fraudDetectionService.FraudThresholdTransaction(transaction) || fraudDetectionService.FraudcountTransaction(transaction.getAccountNo())){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("fraud transaction detected...account blocked");
        }
        ResponseEntity<?>response=transactionService.subtractTransaction(transaction.getAccountNo(), transaction.getAmount());
        return response;
    }

    //to fetch all past transactions made by user
    @GetMapping("/transactions/{accountNo}")
    public ResponseEntity<List<Transaction>> getalltransactions(@PathVariable String accountNo){
        List<Transaction> transaction=transactionService.getalltransactions(accountNo);
        if(transaction.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(transaction);
    }


}






