package microservice.example.trampoline.repository;


import microservice.example.trampoline.models.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepo extends JpaRepository<UserAccount,Integer> {

    UserAccount findByaccountNo(String accountNo);

    boolean existsByAccountNo(String accountNo);


}
