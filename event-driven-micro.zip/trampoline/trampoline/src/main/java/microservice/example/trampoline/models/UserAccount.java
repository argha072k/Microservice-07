package microservice.example.trampoline.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;




@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "users")
public class UserAccount {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;
    private String accountNo;
    private String Username;
    private  double balance=0;

    public enum accountstatus{
        BLOCKED,
        UNBLOCKED
    }


    @Enumerated(EnumType.STRING)
    private accountstatus status= accountstatus.valueOf("UNBLOCKED");


    private int blockAttempts;
    private boolean permanentBlocked=false;



}

