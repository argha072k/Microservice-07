package microservice.example.trampoline.service;
import microservice.example.trampoline.models.Transaction;
import microservice.example.trampoline.models.UserAccount;
import microservice.example.trampoline.repository.AccountRepo;
import microservice.example.trampoline.repository.TransactionRepo;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;

@Service
public class FraudDetectionService {

    private static final double FRAUD_THRESHOLD=50000.0;
    private static final int MAX_TRANSACTION_COUNT=5;
    private static final int TIME_WINDOW=10;

    private AccountRepo accountRepo;
    private TransactionRepo transactionRepo;

    public FraudDetectionService(AccountRepo accountRepo, TransactionRepo transactionRepo) {
        this.accountRepo = accountRepo;
        this.transactionRepo = transactionRepo;
    }

    public boolean FraudAccount(UserAccount account){

        if(Character.isDigit(account.getAccountNo().charAt(0))){
            blockAccount(account.getAccountNo());
            return true;
        }

        return  false;
    }

    public boolean FraudThresholdTransaction(Transaction transaction){

        if(transaction.getAmount()>FRAUD_THRESHOLD){
            blockAccount(transaction.getAccountNo());
            return true;
        }



        return  false;
    }

    public boolean FraudcountTransaction(String accountNo){
        LocalDateTime startTime=LocalDateTime.now().minusMinutes(TIME_WINDOW);
        LocalDateTime endTime=LocalDateTime.now();

        int transactionCount=transactionRepo.countByAccountNoAndTimestampBetween(accountNo,startTime,endTime);

        if(transactionCount>=MAX_TRANSACTION_COUNT){
            blockAccount(accountNo);
            return true;
        }
        return false;

    }

    private void blockAccount(String accountNo){
        UserAccount account=accountRepo.findByaccountNo(accountNo);
        if(account!=null){
            account.setStatus(UserAccount.accountstatus.BLOCKED);
            accountRepo.save(account);
        }
    }


    
}
