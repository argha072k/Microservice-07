package microservice.example.trampoline.service;


import microservice.example.trampoline.models.Transaction;
import microservice.example.trampoline.models.UserAccount;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;


@Service
public class NotificationHandler {


    private static final Logger LOGGER= LoggerFactory.getLogger(NotificationHandler.class);
    @KafkaListener(topics = "account-details",groupId = "joinees")
    public void sendAccountNotification(UserAccount account){

        LOGGER.info(String.format("New account accepted for User -> %s ",account.toString()));
    }

    @KafkaListener(topics="transaction-details",groupId = "joinees")
    public void sendTransactionNotification(Transaction transaction){
        LOGGER.info(String.format("New transaction process accepted for User -> %s ",transaction.toString()));
    }

}
