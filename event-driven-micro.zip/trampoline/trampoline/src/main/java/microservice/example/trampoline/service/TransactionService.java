package microservice.example.trampoline.service;


import jakarta.transaction.Transactional;
import microservice.example.trampoline.models.Transaction;
import microservice.example.trampoline.models.UserAccount;
import microservice.example.trampoline.repository.AccountRepo;
import microservice.example.trampoline.repository.TransactionRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;




import java.util.List;


@Service
@Transactional
public class TransactionService {
    @Autowired
    private final TransactionRepo transactionRepo;
    @Autowired
    private final KafkaTemplate kafkaTemplate;

    @Autowired
    private final AccountRepo accountRepo;

    private static final Logger LOGGER= LoggerFactory.getLogger(AccountService.class);
    public TransactionService(TransactionRepo transactionRepo, KafkaTemplate kafkaTemplate, AccountRepo accountRepo) {
        this.transactionRepo = transactionRepo;
        this.kafkaTemplate = kafkaTemplate;

        this.accountRepo = accountRepo;
    }

    public ResponseEntity<?> addTransaction(String accountNo, double amount){
        UserAccount account= accountRepo.findByaccountNo(accountNo);

        if(!accountRepo.existsByAccountNo(accountNo)){
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("account doesn't exist, make a new account first");
        } else if (account.getStatus()== UserAccount.accountstatus.BLOCKED) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("account is already blocked earlier via fraud transaction");
        }
        double currentBal=account.getBalance();
        double newBal=currentBal+amount;
        account.setBalance(newBal);

        Transaction transaction=new Transaction();
        transaction.setAccountNo(account.getAccountNo());
        transaction.setAmount(amount);
        transactionRepo.save(transaction);

        LOGGER.info(String.format("Account credit by for user -> %s ",transaction));
        kafkaTemplate.send("transaction-details",transaction);
        return ResponseEntity.ok(transaction);
    }


    public ResponseEntity<?> subtractTransaction(String accountNo, double amount){
        UserAccount account=  accountRepo.findByaccountNo(accountNo);
        double currentBal=account.getBalance();
        double newBal=currentBal-amount;
        if (!accountRepo.existsByAccountNo(accountNo)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("account doesn't exist, make a new account first");
        } else if (account.getStatus()== UserAccount.accountstatus.BLOCKED) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("account is already blocked earlier via fraud transaction");
        }
        else if(newBal<0){
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Insufficient Balance");
        }

        account.setBalance(newBal);


        Transaction transaction=new Transaction();
        transaction.setAccountNo(account.getAccountNo());
        transaction.setAmount(-amount);
        transactionRepo.save(transaction);

        LOGGER.info(String.format("Account debited by for user -> %s ",transaction));
        kafkaTemplate.send("transaction-details",transaction);

        return ResponseEntity.ok(transaction);
    }


    public List<Transaction> getalltransactions(String accountNo){
        return transactionRepo.findByaccountNo(accountNo);
    }

}
