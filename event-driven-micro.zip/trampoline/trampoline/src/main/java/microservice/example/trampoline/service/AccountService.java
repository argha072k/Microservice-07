package microservice.example.trampoline.service;


import jakarta.transaction.Transactional;
import microservice.example.trampoline.models.UserAccount;
import microservice.example.trampoline.repository.AccountRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;


@Service
@Transactional
public class AccountService{
    @Autowired
    private final AccountRepo accountRepo;

    private final KafkaTemplate kafkaTemplate;

    private static final int MAX_ATTEMPTS=3;

    private static final Logger LOGGER= LoggerFactory.getLogger(AccountService.class);

    public AccountService(AccountRepo accountRepo, KafkaTemplate kafkaTemplate) {
        this.accountRepo = accountRepo;
        this.kafkaTemplate = kafkaTemplate;
    }

    public ResponseEntity<?> createaccount(UserAccount account){
        UserAccount newaccount=new UserAccount();
        newaccount.setAccountNo(account.getAccountNo());
        newaccount.setUsername(account.getUsername());

        if(accountRepo.existsByAccountNo(newaccount.getAccountNo())){
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("account number already exits, try another account number");
        } else if (newaccount==null)
        {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("account cannot be null");
        } else if (newaccount.getStatus()== UserAccount.accountstatus.BLOCKED) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("account is already blocked");
        }
        accountRepo.save(newaccount);

        LOGGER.info(String.format("New account created for User -> %s ",newaccount));
        kafkaTemplate.send("account-details",newaccount);

        return ResponseEntity.ok(newaccount);
    }

    public ResponseEntity<?> unblockaccount(String accountNo){
        UserAccount account=accountRepo.findByaccountNo(accountNo);
        if(account.isPermanentBlocked()){
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("account permanently blocked");
        }

        if(account.getBlockAttempts()>=MAX_ATTEMPTS){
            account.setPermanentBlocked(true);
            accountRepo.save(account);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Account permanently blocked due to multiple block attempts");
        }
        if(account.getStatus()!= UserAccount.accountstatus.BLOCKED){
            return ResponseEntity.ok("Account is not blocked");
        }
        account.setStatus(UserAccount.accountstatus.UNBLOCKED);
        account.setBlockAttempts(account.getBlockAttempts()+1);
        accountRepo.save(account);

        return ResponseEntity.ok("Account Unblocked Successfully");
    }


    public UserAccount getbyAccountNo(String accountNo){
            return accountRepo.findByaccountNo(accountNo);
    }






}