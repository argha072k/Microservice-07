package microservice.example.trampoline.repository;


import microservice.example.trampoline.models.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface TransactionRepo extends JpaRepository<Transaction,Long> {



   List<Transaction> findByaccountNo(String accountNo);

   int countByAccountNoAndTimestampBetween(String accountNo, LocalDateTime startTime, LocalDateTime endTime);

}
