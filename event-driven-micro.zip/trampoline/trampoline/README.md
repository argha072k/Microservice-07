# trampoline

## Entities
- [x] Account
- [x] Transaction

## Services
- [ ] Fraudulent transaction detection
- [ ] Account service
- [ ] Transaction service


## Kafka configuration
- [x] serializer and deserializer
- [x] topic configuration

## Data Flow Diagram
todo
